# React__Todo-App

<h4 style='font-weight: 500'> Features:</h4>

<ol type="1"> 
<li> Searching Funtionality </li>
<li> Filtering Funtionality </li>
<li> Running, Completed Funtionality </li>
<li> Clearing Funtionality </li>
<li> Reset Funtionality </li>
<li> Delete Funtionality </li>
<li> List and table view Funtionality </li>

</ol>
